# Site Watch v2

An advanced website dashboard: live metrics, product management, smart alerts, root-cause tracking and an activity log, behind a login.

## What is new in v2
- Login (signed token, no extra packages)
- Live updates without refreshing (Server-Sent Events)
- Data saved to `backend/data.json`, so it survives restarts
- Tabs: Overview, Alerts, Products, Settings
- Charts: sales trend and open alerts by type
- Alert insights (for example, how fast a product is selling), root-cause checklist, root-cause and action notes, status
- Edit alert limits in the Settings tab
- Add customer reviews; bad ones raise alerts
- Activity log of who changed what
- Optional Slack/Discord/Teams webhook when a new alert appears
- Built-in demo traffic simulator, so you can watch alerts appear

## Run it (Node 18 or newer)
```bash
cd backend
npm install
npm start
```
Open http://localhost:3000 and sign in with `admin` / `admin123`.

## Settings (environment variables)
| Variable | Purpose | Default |
|---|---|---|
| PORT | Server port | 3000 |
| ADMIN_USER / ADMIN_PASS | Login | admin / admin123 |
| SECRET | Signs login tokens | change-this-secret |
| WEBHOOK_URL | Alert notifications to Slack, Discord or Teams | off |

Example: `ADMIN_PASS=MyStrongPass SECRET=longrandomtext WEBHOOK_URL=https://hooks.slack.com/... npm start`

Change the defaults before putting this on the internet, and serve it over HTTPS.

## Project structure
```
backend/server.js    API, login, alert engine, live stream, simulator
backend/package.json
frontend/index.html  dashboard UI
```

## API (all need a login token, except /api/login)
| Method | Path | Purpose |
|---|---|---|
| POST | /api/login | Get a token |
| GET | /api/stream | Live data stream |
| PATCH | /api/alerts/:id | Update status, rootCause, action |
| POST | /api/products | Add product |
| PUT / DELETE | /api/products/:id | Edit or delete |
| POST | /api/reviews | Add a review |
| PUT | /api/limits | Change alert limits |

## Connect real data
In `server.js`, delete the "Demo traffic simulator" block and update `db.metrics` and `db.orders` from your real sources: Google Analytics (traffic), your payment gateway webhooks (failed payments), Sentry (errors), and your store's order events. Then call `push()` after each update.

## Next ideas
Multiple users and roles, a real database (PostgreSQL), email alerts, and exporting reports to CSV.
