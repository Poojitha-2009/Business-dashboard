# Site Watch: Cancellation Diagnosis for an Online Store

## 1. Problem diagnosis
Online stores lose money when customers cancel orders, and the cause is rarely visible in one place. The reasons sit in different teams' tools:

| Area | Signal | What it can cause |
|---|---|---|
| Cancellation reasons | Late delivery, out of stock, price, payment failed | Direct lost revenue |
| Partner stores | On-time %, fill rate, rejection rate | Late or missing orders |
| Marketing | Ad spend vs revenue | Paying for traffic that does not convert |
| Customer support | First-reply time, satisfaction, top topic | Unhappy customers who cancel and leave |
| Competitors | Price gap, promos, delivery time | Customers switching at checkout |

**The core problem:** teams see symptoms (cancellations up) but not the root cause, so they react slowly or fix the wrong thing.

## 2. Journey (problem to fix)
1. **Detect:** limits on each signal raise an alert with an owner.
2. **Diagnose:** the engine links signals into one root cause with evidence and confidence.
3. **Decide:** it lists solutions and who should act.
4. **Act:** the owner records root cause and action on the alert.
5. **Verify:** the alert closes when numbers recover; the activity log keeps the history.

Example: cancellations jump to 29%, 75% say "late delivery", QuickShop HSR on-time falls to 68%, support replies slow to 42 minutes. Diagnosis: late dispatch at QuickShop HSR. Solution: reroute orders, call the store, show honest ETAs, send apology coupons.

## 3. Solution explanation
- **Signals tab** shows cancellations by reason, partner stores, marketing return, support and competitors in one place.
- **Alerts** fire from editable limits (Settings tab) and notify owners (optional webhook).
- **Diagnosis tab** correlates signals using rules in `backend/insights.js` (`diagnose`). Rules currently cover partner delays, competitor price moves and slow support. Add new rules there.
- **Business impact** converts cancellations into rupees: total lost, avoidable (late delivery, out of stock, payment failed, wrong item) and recoverable (assumed 60% of avoidable).

## 4. Functional prototype
Run it as described in the README. The prototype uses simulated data and two scenario buttons (Diagnosis tab): **Partner store runs late** and **Competitor price war**. To use real data, replace the simulator with your order, partner, ads and support feeds.

## 5. Demo video (about 3 minutes)
Record your screen (Windows: Win+G, Mac: Shift+Cmd+5, phone: screen recorder) while following this script.

| Time | Screen | Say |
|---|---|---|
| 0:00 | Overview tab | "Stores lose money to cancellations but cannot see why. Site Watch finds the cause." |
| 0:20 | Signals tab | "Here are cancellation reasons, partner stores, ads, support and competitors in one view." |
| 0:50 | Diagnosis tab, click **Partner store runs late** | "Now a partner store starts delivering late." |
| 1:10 | Diagnosis tab | "The system links late delivery, the slow store and slow support into one root cause, with evidence and a fix list." |
| 1:50 | Alerts tab, open one alert | "The owner writes the root cause and the action and sets the status." |
| 2:15 | Diagnosis tab, click **Reset**, then **Competitor price war** | "A different cause, a different diagnosis and solution." |
| 2:40 | Impact cards | "Business impact: lost revenue, avoidable losses and what we can recover." |

## 6. Business impact (illustrative assumptions, replace with your numbers)
Assume 1,000 orders a day, average order value ₹600, cancellation rate 12%.
- Cancelled: 120 orders = ₹72,000 a day lost
- Avoidable share (50%): ₹36,000 a day
- Recovered with faster diagnosis and fixes (60%): about ₹21,600 a day, roughly ₹6.5 lakh a month

Other benefits: faster response (minutes instead of days to find a cause), fewer support tickets, better partner accountability, and smarter ad spend.
