// Site Watch v2: login, saved data, live updates, alert engine, webhook notifications.
const express = require("express"), cors = require("cors"), fs = require("fs"), path = require("path"), crypto = require("crypto");
const PORT = process.env.PORT || 3000, SECRET = process.env.SECRET || "change-this-secret";
const ADMIN = { user: process.env.ADMIN_USER || "admin", pass: process.env.ADMIN_PASS || "admin123" };
const WEBHOOK = process.env.WEBHOOK_URL; // Slack/Discord/Teams incoming webhook (optional)
const DB_FILE = path.join(__dirname, "data.json");
const OWNERS = { stock: "Stock manager", payment: "Finance team", traffic: "Marketing", error: "Developer", review: "Support team" };
const CAUSES = {
  stock: ["Supplier delay?", "Demand spike?", "Stock count wrong?"],
  payment: ["Gateway down?", "One bank declining cards?", "Checkout bug after a release?"],
  traffic: ["Search ranking drop?", "Ad campaign stopped?", "Site slow or down?", "Broken home page link?"],
  error: ["Last deploy broke something?", "Third-party API failing?", "Check server logs at first error time"],
  review: ["Product defect or bad batch?", "Late or damaged delivery?", "Wrong description?"],
};

// ---- Saved data (JSON file). Swap for MongoDB/PostgreSQL in production ----
const seed = {
  limits: { lowStock: 10, failedPayments: 3, trafficDropPct: 30, errors: 5, badRating: 2 },
  products: [{ id: 1, name: "Wireless Mouse", price: 899, stock: 42 }, { id: 2, name: "USB-C Cable", price: 299, stock: 14 }, { id: 3, name: "Laptop Stand", price: 1499, stock: 18 }],
  orders: [], reviews: [], alerts: [], log: [],
  metrics: { visitorsToday: 820, visitorsYesterday: 1000, orders: 0, sales: 0, signups: 19, failedPayments: 0, errors: 0,
    topPages: [{ page: "/home", views: 540 }, { page: "/products", views: 310 }, { page: "/checkout", views: 120 }],
    salesByDay: [31000, 36500, 38200, 40100, 44800, 43900, 0] },
};
let db = fs.existsSync(DB_FILE) ? JSON.parse(fs.readFileSync(DB_FILE)) : seed;
const save = () => fs.writeFileSync(DB_FILE, JSON.stringify(db));
const audit = (who, what) => db.log.push({ at: new Date().toISOString(), who, what });

// ---- Auth (signed token, no extra packages) ----
const sign = s => crypto.createHmac("sha256", SECRET).update(s).digest("hex");
const makeToken = u => { const p = Buffer.from(JSON.stringify({ u, exp: Date.now() + 864e5 })).toString("base64url"); return p + "." + sign(p); };
const verify = t => { try { const [p, s] = t.split("."); return s === sign(p) && JSON.parse(Buffer.from(p, "base64url")).exp > Date.now(); } catch { return false; } };
const auth = (req, res, next) => verify((req.headers.authorization || "").replace("Bearer ", "") || req.query.token || "") ? next() : res.status(401).json({ error: "Login required" });

// ---- Alert engine ----
function detect() {
  const L = db.limits, m = db.metrics, found = [];
  const recent = db.orders.slice(-100);
  db.products.filter(p => p.stock < L.lowStock).forEach(p => {
    const sold = recent.filter(o => o.productId === p.id).length;
    found.push({ key: "stock-" + p.id, type: "stock", severity: p.stock < 5 ? "high" : "medium", message: `Low stock: ${p.name} has ${p.stock} left`,
      insight: `${sold} of the last ${recent.length} orders were this product. Reorder soon.` });
  });
  if (m.failedPayments > L.failedPayments) found.push({ key: "payment", type: "payment", severity: "high", message: `${m.failedPayments} failed payments recently`, insight: "Check the payment gateway status page first." });
  const drop = Math.round((1 - m.visitorsToday / m.visitorsYesterday) * 100);
  if (drop >= L.trafficDropPct) found.push({ key: "traffic", type: "traffic", severity: "medium", message: `Traffic is down ${drop}% vs yesterday`, insight: "Compare with the same hour yesterday before reacting." });
  if (m.errors > L.errors) found.push({ key: "error", type: "error", severity: "high", message: `${m.errors} site errors recently`, insight: "Check whether errors started right after a deploy." });
  db.reviews.filter(r => r.rating <= L.badRating).forEach(r => found.push({ key: "review-" + r.id, type: "review", severity: "medium", message: `Bad review (${r.rating} stars) on ${r.product}: "${r.text}"`, insight: "Reply to the customer and check other reviews of this product." }));
  return found;
}
function notify(a) {
  console.log(`ALERT [${a.severity}] ${a.message} -> ${a.owner}`);
  if (WEBHOOK) fetch(WEBHOOK, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ text: `[${a.severity}] ${a.message} (owner: ${a.owner})` }) }).catch(() => {});
}
function sync() {
  const found = detect();
  found.forEach(f => {
    if (!db.alerts.find(a => a.key === f.key && a.status !== "resolved")) {
      const a = { ...f, id: crypto.randomUUID(), owner: OWNERS[f.type], causes: CAUSES[f.type], status: "open", rootCause: "", action: "", createdAt: new Date().toISOString() };
      db.alerts.push(a); notify(a);
    }
  });
  db.alerts.forEach(a => { if (a.status !== "resolved" && !found.find(f => f.key === a.key)) { a.status = "resolved"; audit("system", `Auto-resolved: ${a.message}`); } });
}

// ---- Live updates (Server-Sent Events) ----
const clients = new Set();
const state = () => ({ metrics: db.metrics, products: db.products, orders: db.orders.slice(-12).reverse(), reviews: db.reviews, alerts: [...db.alerts].reverse(), limits: db.limits, log: db.log.slice(-15).reverse() });
const push = () => { sync(); save(); const d = `data: ${JSON.stringify(state())}\n\n`; clients.forEach(c => c.write(d)); };

// ---- Demo traffic simulator (delete this block when you connect real data) ----
let tick = 0;
setInterval(() => {
  const m = db.metrics; tick++;
  m.visitorsToday += Math.floor(Math.random() * 9);
  if (Math.random() < 0.4 && db.products.length) {
    const p = db.products[Math.floor(Math.random() * db.products.length)];
    if (p.stock > 0) { p.stock--; m.orders++; m.sales += p.price; m.salesByDay[6] += p.price; db.orders.push({ id: Date.now(), productId: p.id, product: p.name, amount: p.price, at: new Date().toISOString() }); }
  }
  if (Math.random() < 0.1) m.failedPayments++;
  if (Math.random() < 0.06) m.errors++;
  if (tick % 12 === 0) { m.failedPayments = Math.floor(m.failedPayments / 2); m.errors = Math.floor(m.errors / 2); }
  push();
}, 5000);

// ---- API ----
const app = express();
app.use(cors(), express.json());
app.use(express.static(path.join(__dirname, "../frontend")));
app.post("/api/login", (req, res) => {
  const { user, pass } = req.body || {};
  if (user === ADMIN.user && pass === ADMIN.pass) return res.json({ token: makeToken(user) });
  res.status(401).json({ error: "Wrong username or password" });
});
app.use("/api", auth);
app.get("/api/stream", (req, res) => {
  res.set({ "Content-Type": "text/event-stream", "Cache-Control": "no-cache", Connection: "keep-alive" });
  clients.add(res); sync(); res.write(`data: ${JSON.stringify(state())}\n\n`);
  req.on("close", () => clients.delete(res));
});
app.patch("/api/alerts/:id", (req, res) => {
  const a = db.alerts.find(x => x.id === req.params.id); if (!a) return res.status(404).json({ error: "Alert not found" });
  const { status, rootCause, action } = req.body;
  Object.assign(a, { ...(status && { status }), ...(rootCause !== undefined && { rootCause }), ...(action !== undefined && { action }) });
  audit("admin", `Updated alert (${a.status}): ${a.message}`); push(); res.json(a);
});
app.post("/api/products", (req, res) => {
  const { name, price, stock } = req.body;
  if (!name || !(price >= 0) || !(stock >= 0)) return res.status(400).json({ error: "Valid name, price and stock are required" });
  const p = { id: Date.now(), name, price: +price, stock: +stock }; db.products.push(p); audit("admin", `Added product ${name}`); push(); res.status(201).json(p);
});
app.put("/api/products/:id", (req, res) => {
  const p = db.products.find(x => String(x.id) === req.params.id); if (!p) return res.status(404).json({ error: "Product not found" });
  Object.assign(p, req.body); audit("admin", `Edited product ${p.name}`); push(); res.json(p);
});
app.delete("/api/products/:id", (req, res) => { db.products = db.products.filter(x => String(x.id) !== req.params.id); audit("admin", "Deleted a product"); push(); res.status(204).end(); });
app.post("/api/reviews", (req, res) => {
  const { product, rating, text } = req.body;
  if (!product || !(rating >= 1 && rating <= 5)) return res.status(400).json({ error: "Product and rating (1-5) are required" });
  db.reviews.push({ id: Date.now(), product, rating: +rating, text: text || "" }); push(); res.status(201).end();
});
app.put("/api/limits", (req, res) => { Object.keys(db.limits).forEach(k => { if (req.body[k] >= 0) db.limits[k] = +req.body[k]; }); audit("admin", "Changed alert limits"); push(); res.json(db.limits); });

app.listen(PORT, () => console.log(`Dashboard running at http://localhost:${PORT}  (login: ${ADMIN.user} / ${ADMIN.pass})`));
