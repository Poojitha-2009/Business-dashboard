// Business signals: cancellations, partner stores, marketing, support, competitors,
// plus the diagnosis engine (links signals to a root cause and a solution) and business impact.
const REASONS = ["Late delivery", "Item out of stock", "Price too high", "Payment failed", "Found cheaper elsewhere", "Wrong item", "Changed mind"];
const CONTROLLABLE = ["Late delivery", "Item out of stock", "Payment failed", "Wrong item"];
const rnd = (a, b) => a + Math.random() * (b - a), pick = a => a[Math.floor(Math.random() * a.length)], clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const defaults = () => ({
  partners: [{ name: "CityMart Koramangala", onTime: 94, fillRate: 96, reject: 3 }, { name: "FreshBasket Indiranagar", onTime: 91, fillRate: 93, reject: 4 }, { name: "QuickShop HSR", onTime: 90, fillRate: 91, reject: 5 }],
  campaigns: [{ name: "Instagram Ads", spend: 12000, revenue: 30000 }, { name: "Google Search", spend: 15000, revenue: 42000 }, { name: "Email Offers", spend: 2000, revenue: 9000 }],
  support: { open: 12, avgResponse: 14, csat: 4.4, topTopic: "Delivery status" },
  competitors: [{ name: "BlinkRival", priceGap: 2, deliveryMin: 20, promo: false }, { name: "ZipMart", priceGap: 3, deliveryMin: 25, promo: false }],
});
function init(db) {
  db.cancellations = db.cancellations || [];
  Object.entries(defaults()).forEach(([k, v]) => { db[k] = db[k] || v; });
  db.limits = Object.assign({ cancelRate: 10, partnerOnTime: 85, roas: 2, responseMin: 30, csat: 4, priceGap: 6 }, db.limits);
}
function win(db) {
  const t = Date.now() - 3e5;
  const o = db.orders.filter(x => new Date(x.at) > t).length, c = db.cancellations.filter(x => new Date(x.at) > t);
  const counts = {}; c.forEach(x => counts[x.reason] = (counts[x.reason] || 0) + 1);
  const top = Object.entries(counts).sort((a, b) => b[1] - a[1])[0];
  return { o, c, rate: o + c.length ? Math.round(c.length / (o + c.length) * 100) : 0, top: top && { reason: top[0], n: top[1], share: Math.round(top[1] / c.length * 100) } };
}
function addCancel(db, reason, partner) {
  db.cancellations.push({ reason, partner: partner.name, amount: Math.round(rnd(250, 1500)), at: new Date().toISOString() });
}
function tick(db) {
  const L = db.limits, late = db.partners.filter(p => p.onTime < L.partnerOnTime), war = db.competitors.some(c => c.priceGap >= L.priceGap);
  if (Math.random() < 0.04 + (late.length ? 0.12 : 0) + (war ? 0.08 : 0)) {
    const p = late.length && Math.random() < 0.7 ? pick(late) : pick(db.partners);
    let r = pick(REASONS);
    if (late.includes(p) && Math.random() < 0.7) r = "Late delivery"; else if (war && Math.random() < 0.5) r = "Found cheaper elsewhere";
    addCancel(db, r, p);
  }
  db.campaigns.forEach(c => { c.spend += rnd(20, 80); c.revenue += rnd(40, 200) * (db.competitors.some(x => x.promo) ? 0.5 : 1); });
  const s = db.support; s.avgResponse = clamp(s.avgResponse + rnd(-.6, .6), 5, 90); s.csat = clamp(s.csat + rnd(-.03, .03), 1, 5);
  db.partners.forEach(p => p.onTime = clamp(p.onTime + rnd(-.3, .3), 40, 99));
  db.competitors.forEach(c => c.priceGap = clamp(c.priceGap + rnd(-.2, .2), 0, 20));
  if (db.orders.length > 400) db.orders.splice(0, 100);
  if (db.cancellations.length > 400) db.cancellations.splice(0, 100);
}
function scenario(db, name) {
  if (name === "reset") { Object.assign(db, defaults()); db.cancellations = []; return; }
  if (name === "late-partner") {
    const p = db.partners[2]; p.onTime = 68; p.fillRate = 80; p.reject = 14;
    db.support.avgResponse = 42; db.support.csat = 3.6; db.support.open = 38; db.support.topTopic = "Where is my order";
    for (let i = 0; i < 8; i++) addCancel(db, i < 6 ? "Late delivery" : pick(REASONS), p);
  }
  if (name === "price-war") {
    const c = db.competitors[0]; c.priceGap = 9; c.promo = true; c.deliveryMin = 15;
    db.campaigns[0].revenue *= 0.5;
    for (let i = 0; i < 7; i++) addCancel(db, i < 5 ? "Found cheaper elsewhere" : "Price too high", pick(db.partners));
  }
}
function detect(db) {
  const L = db.limits, w = win(db), out = [];
  const add = (key, type, severity, message, insight, owner, causes) => out.push({ key, type, severity, message, insight, owner, causes });
  if (w.o + w.c.length >= 8 && w.rate > L.cancelRate)
    add("cancel-rate", "cancellation", "high", `Cancellation rate is ${w.rate}% in the last 5 minutes (limit ${L.cancelRate}%)`,
      w.top ? `Main reason: ${w.top.reason} (${w.top.share}%).` : "", "Operations lead", ["Late delivery?", "Out-of-stock items?", "Price or competitor offer?", "Payment failures?"]);
  db.partners.forEach(p => { if (p.onTime < L.partnerOnTime)
    add("partner-" + p.name, "partner", "high", `Partner store ${p.name}: on-time delivery ${Math.round(p.onTime)}% (limit ${L.partnerOnTime}%)`,
      `Fill rate ${p.fillRate}%, order rejection ${p.reject}%.`, "Partner manager", ["Not enough riders or packers?", "Stock mismatch at store?", "Peak-hour overload?", "Slow order acceptance?"]); });
  db.campaigns.forEach(c => { const r = c.revenue / c.spend; if (r < L.roas)
    add("mkt-" + c.name, "marketing", "medium", `${c.name}: return on ad spend is ${r.toFixed(1)}x (limit ${L.roas}x)`,
      "Spending more than it earns back.", "Marketing", ["Wrong audience?", "Competitor promo running?", "Stale creative?", "Landing page or checkout drop-off?"]); });
  const s = db.support;
  if (s.avgResponse > L.responseMin || s.csat < L.csat)
    add("support", "support", "medium", `Support: first reply ${Math.round(s.avgResponse)} min, satisfaction ${s.csat.toFixed(1)}/5`,
      `Top topic: ${s.topTopic}. ${s.open} open tickets.`, "Support lead", ["Too few agents at peak?", "Repeated question that needs an auto-reply?", "Delivery problem upstream?"]);
  db.competitors.forEach(c => { if (c.priceGap >= L.priceGap || (c.promo && c.deliveryMin < 30))
    add("comp-" + c.name, "competitor", "medium", `${c.name} is ${c.priceGap.toFixed(0)}% cheaper${c.promo ? " and running a promo" : ""}, delivers in ${c.deliveryMin} min`,
      "Customers may switch during checkout.", "Category manager", ["Match price on top items?", "Counter with a targeted offer?", "Highlight our delivery or quality?"]); });
  return out;
}
function diagnose(db) {
  const L = db.limits, w = win(db), out = [];
  const latePs = db.partners.filter(p => p.onTime < L.partnerOnTime), war = db.competitors.find(c => c.priceGap >= L.priceGap), s = db.support;
  if (w.top && w.top.reason === "Late delivery" && w.top.share >= 35 && latePs.length) {
    const p = latePs[0];
    out.push({ title: "Late dispatch at a partner store is driving cancellations", owner: "Operations", confidence: s.avgResponse > L.responseMin ? "High" : "Medium",
      rootCause: `${p.name} is delivering late, so customers cancel and then flood support.`,
      evidence: [`${w.top.share}% of recent cancellations say late delivery`, `${p.name} on-time rate is ${Math.round(p.onTime)}% (limit ${L.partnerOnTime}%)`, `Fill rate ${p.fillRate}%, rejections ${p.reject}%`, `Support first reply ${Math.round(s.avgResponse)} min, top topic "${s.topTopic}"`],
      solution: ["Route new orders to the nearest healthy partner store", "Call the store: check riders, packers and stock", "Show an honest delivery time at checkout", "Message affected customers with a small coupon", "Re-check on-time rate in 24 hours"] });
  }
  if (w.top && ["Found cheaper elsewhere", "Price too high"].includes(w.top.reason) && war) {
    const weak = db.campaigns.find(c => c.revenue / c.spend < L.roas);
    out.push({ title: "A competitor price move is pushing customers to cancel", owner: "Category manager", confidence: weak ? "High" : "Medium",
      rootCause: `${war.name} is ${war.priceGap.toFixed(0)}% cheaper${war.promo ? " with an active promo" : ""}.`,
      evidence: [`${w.top.share}% of recent cancellations cite price`, `${war.name} delivers in ${war.deliveryMin} min`, ...(weak ? [`${weak.name} return on ad spend fell to ${(weak.revenue / weak.spend).toFixed(1)}x`] : [])],
      solution: ["Match price on the top 5 items for 48 hours", "Send a targeted offer to carts at risk", "Pause or retarget the weak ad campaign", "Promote our delivery speed and quality"] });
  }
  if (s.avgResponse > L.responseMin && s.csat < L.csat && !out.length)
    out.push({ title: "Slow support is hurting satisfaction", owner: "Support lead", confidence: "Medium", rootCause: `First reply takes ${Math.round(s.avgResponse)} minutes.`,
      evidence: [`Satisfaction ${s.csat.toFixed(1)}/5`, `${s.open} open tickets, top topic "${s.topTopic}"`], solution: ["Auto-reply with live order status", "Add agents at peak hours", "Create saved replies for the top topic"] });
  return out;
}
function impact(db) {
  const c = db.cancellations, lost = c.reduce((a, x) => a + x.amount, 0);
  const controllable = c.filter(x => CONTROLLABLE.includes(x.reason)).reduce((a, x) => a + x.amount, 0);
  const o = db.orders.length;
  return { lost, count: c.length, rate: o + c.length ? Math.round(c.length / (o + c.length) * 100) : 0, controllable, recoverable: Math.round(controllable * 0.6) };
}
function signals(db) {
  const by = {}; db.cancellations.forEach(x => { by[x.reason] = by[x.reason] || { reason: x.reason, count: 0, amount: 0 }; by[x.reason].count++; by[x.reason].amount += x.amount; });
  return { reasons: Object.values(by).sort((a, b) => b.count - a.count), partners: db.partners, campaigns: db.campaigns.map(c => ({ ...c, roas: +(c.revenue / c.spend).toFixed(1) })), support: db.support, competitors: db.competitors };
}
module.exports = { init, tick, scenario, detect, diagnose, impact, signals };
