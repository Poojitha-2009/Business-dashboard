# Nova Cart Watch: Cancellation Diagnosis and Action Dashboard

## Problem statement
Nova Cart is losing orders to cancellations, and no one can see why. The causes sit in separate places: cancellation reasons, partner store performance, marketing spend, customer support and competitor moves. Teams notice the symptom late, disagree on the cause, and often fix the wrong thing.

**Question:** if Nova Cart builds one new intervention right now, what should it build?

## The intervention
A dashboard that does three things:
1. **Detect:** alerts owners when cancellations, failed payments, low stock, partner delays, traffic drops or bad reviews cross a limit.
2. **Diagnose:** links the signals into one root cause with evidence and a confidence level.
3. **Act:** gives each alert an owner, a ranked fix list, and a place to record the root cause, the action and the status.

**Why this first:** cancellations are a measurable revenue leak, most causes are controllable (late delivery, out of stock, payment failure, wrong item), it uses data Nova Cart already has, and it fixes causes rather than adding more offers or ad spend.

**Success measures:** lower cancellation rate, root cause found in minutes instead of days, better partner on-time rate, faster support replies, revenue recovered from avoidable cancellations.

## Features
- Login, live updates, saved data, activity log
- Signals tab: cancellation reasons, partner stores, marketing, support, competitors
- Diagnosis tab: root cause, evidence, solutions, business impact, demo scenario buttons
- Alerts with owners, root-cause checklist, notes and status
- Product management and customer reviews
- Editable alert limits (Settings tab)
- Optional Slack/Discord/Teams webhook for new alerts

## Run it (Node 18 or newer)
```bash
cd backend
npm install
npm start
```
Open http://localhost:3000 and sign in with `admin` / `admin123`.

Try it: Diagnosis tab, tap **Partner store runs late**, read the diagnosis, then open Alerts and record the root cause and action.

## Project structure
```
backend/server.js      API, login, alert engine, live stream, simulator
backend/insights.js    signals, diagnosis rules, business impact
backend/package.json
frontend/index.html    dashboard UI
docs/PROJECT.md        journey, solution explanation, video script, business impact
netlify.toml           Netlify publish folder (frontend)
```

## Settings (environment variables)
| Variable | Purpose | Default |
|---|---|---|
| PORT | Server port | 3000 |
| ADMIN_USER / ADMIN_PASS | Login | admin / admin123 |
| SECRET | Signs login tokens | change-this-secret |
| WEBHOOK_URL | Alert notifications | off |

Change the defaults before putting this online.

## Deploy
Netlify hosts only static files, so it cannot run the backend.
- **Option A (simplest):** host everything on Render or Railway. Root directory `backend`, build command `npm install`, start command `npm start`. The backend also serves the dashboard.
- **Option B:** backend on Render, frontend on Netlify. In `frontend/index.html` set `const API_BASE = "https://your-backend.onrender.com";`, then deploy to Netlify (`netlify.toml` sets the publish folder to `frontend`).

Free hosting may reset `data.json` on restart; use a database for permanent data.

## Connect real data
Delete the "Demo traffic simulator" block in `backend/server.js` and feed real orders, cancellations, partner, ads, support and competitor data into `db`, then call `push()` after each update.
